This archive contains a ServerMap named Quickstart_2026-01-22_11-44-54_built_001.
It was exported by a Bosch Rexroth Locator Server 2.0.1 at 2026-01-22T13:31:53Z.
This archive can be imported into a Bosch Rexroth Locator Server of a compatible version.
Please refer to the product documentation for details.
NOTE: To ensure data integrity, please do not modify this archive.
Changing the contents of this archive in any way may render it unusable.
